courseprovider -Module
===============
Overview
--------

 1.This Plugin lets you add a link to the courses available on other LMS in your Course as an Activity Link. 
 2.This activity lets users to view the courses available in other LMS websites.
 
 Note: 1. Passes user details and "Courseid" of the course which is available on the other LMS site as url parameters in the link.
	   2. User has to login into other LMS site to view the course.


Requirements
------------
Moodle 2.1.5

Installation
------------
   1.Unzip courseprovider.zip file.
   2.Copy the folder �courseprovider� to  �mod� folder of moodle installation.
   3.Login into your moodle website as �admin� and  Go to �Notifications� under �Settings� to install the New Course Provider Plugin.
   

Process to add the activity ina course
--------------------------------------

 Go to your desired Course and �Turn Editing on� and click on Add Activity drop down to find the new activity �Link to a Course on Other LMS� which allows you to add a course available on other LMS.


Plugin Settings Page
--------------------

Below are the required fields to be entered:

General:
--------
Course Name: Name of the Course
Course Description: Description of the Course
URL Details:
------------
Website Base URL: URL of the other LMS
Course ID on other LMS: Course ID of the Course which is there on the other LMS.

After entering the above details click on "Save and return to course" to go back to Course where you will see the Link to the Course with the Course Name.


